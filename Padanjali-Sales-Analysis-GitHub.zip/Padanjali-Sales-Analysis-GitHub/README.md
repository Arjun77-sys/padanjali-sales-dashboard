# Padanjali Ayurvedic: Sales Analysis Dashboard

An exploratory sales analysis of WooCommerce order data for Padanjali Ayurvedic (P) Ltd, a skin treatment centre in Kuttippuram, Kerala that also sells products online. This project was completed as part of a Data Analytics internship. It covers the company profile, dataset review, data cleaning, and Power BI dashboard analysis.

## Dashboard Preview

![Padanjali Ayurvedic Sales Dashboard](Dashboard%20Screenshots/padanjali_sales_dashboard.png)

## Repository Contents

```text
Padanjali-Sales-Analysis-GitHub/
├── Padanjali_Sales_Report.docx
├── README.md
└── Dashboard Screenshots/
    └── padanjali_sales_dashboard.png
```

## Project Overview

The dashboard analyses 690 orders and presents headline KPIs and charts for monthly revenue and orders, average order value by year, revenue by payment method, revenue by product, and revenue by billing country.

## Headline Results

| Metric | Value |
|---|---:|
| Total revenue | 2.52M INR |
| Total orders | 690 |
| Average order value | 3.66K INR |
| Guest orders | 49% |
| Revenue from Razorpay | 99.48% |

## Key Insights

- India contributes about 54% of revenue; the US is the largest overseas market at about 17%.
- Revenue peaks around May and October in the combined monthly view.
- Average order value declined from about 4.6K in 2023 to 2.9K in 2026. Since 2026 is a partial year, this needs further investigation.
- Agnijith 90 gms is the highest-revenue product in the current product chart.
- Nearly all revenue is associated with Razorpay payments.

## Tools and Technologies

- Microsoft Power BI
- Power Query
- DAX
- Microsoft Word

## Data Cleaning

The report describes data-type checks, date/time splitting, conversion of amounts to INR, splitting line-item fields into product-level columns, and checks of billing and shipping location details. The raw data was kept separate from the cleaned query.

## Limitations and Further Analysis

- The product chart uses only the first product slot per order; products in slots 2–4 are not counted.
- Product names need standardisation, including spelling variants of Kasmeerini.
- The monthly chart combines all years; May and October peaks should be checked year by year.
- 2026 is a partial year, so the change in average order value needs more analysis.

## Dataset and Privacy

The WooCommerce dataset is confidential and is not included in this repository. The report contains aggregated results rather than customer-level records.

## Author

**Arjun G**  
Data Analytics learner | Power BI, Excel, SQL, Python
